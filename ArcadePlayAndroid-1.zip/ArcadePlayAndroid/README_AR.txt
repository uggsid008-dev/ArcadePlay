مشروع Arcade Play للأندرويد

طريقة إنشاء APK:
1) نزّل Android Studio على كمبيوتر.
2) فك ضغط ArcadePlayAndroid.zip.
3) من Android Studio اختر Open وافتح مجلد ArcadePlayAndroid نفسه.
4) انتظر Gradle Sync واكتمال تنزيل مكونات Android المطلوبة.
5) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
6) بعد النجاح اضغط locate من إشعار Android Studio للعثور على ملف APK.

ملاحظة: المشروع يحتوي نموذج ألعاب ترفيهية بنقاط افتراضية فقط، ولا يتضمن مراهنات أو إيداعًا أو سحبًا ماليًا.
